import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { AboutusComponent } from './aboutus/aboutus.component';
import { EncuentranosComponent } from './encuentranos/encuentranos.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/index', pathMatch: 'full' },

  { path: 'aboutus', component: AboutusComponent },
  { path: 'encuentranos', component: EncuentranosComponent },
  // more routes can go here
];


@NgModule({
  declarations: [
    AppComponent,
    AboutusComponent,
    EncuentranosComponent,
    HeaderComponent,
    FooterComponent,
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
