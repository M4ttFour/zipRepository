import { Component } from '@angular/core';

@Component({
  selector: 'app-encuentranos',
  templateUrl: './encuentranos.component.html',
  styleUrls: ['./encuentranos.component.css']
})
export class EncuentranosComponent {

}
