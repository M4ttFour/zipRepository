fetch('https://raw.githubusercontent.com/M4ttFour/myRepository/main/data.json')
.then(response => {
    console.log('Data received', response);
    return response.json();
})
.then(data => {
    console.log('Parsed JSON data', data);

    //Ciclo Carousel
    const carouselItems = data.carousel;
    console.log('Carousel items', carouselItems);

    const carouselContainer = document.getElementsByClassName("carousel-inner")[0];
    for (let i = 0; i < carouselItems.length; i++) {
        const carouselItem = document.createElement('div');
        carouselItem.classList.add('carousel-item');
        const img = document.createElement('img');
        img.setAttribute('src', carouselItems[i].img);
        img.setAttribute('alt', `Slide ${i + 1}`);
        img.classList.add('img-fluid','w-100');
        carouselItem.appendChild(img);
        carouselContainer.appendChild(carouselItem);
        if (i === 0) {
            carouselItem.classList.add('active');
        } 
    }

    //Ciclo de Cartas
    const cardsItems = data.cards;
    console.log('Card items', cardsItems);

    const cardsContainer = document.getElementById("card-row");
    for (let i = 0; i < cardsItems.length; i++) {
        const col = document.createElement('div');
        col.classList.add('pt-5', 'col-lg-3', 'col-md-6', 'col-sm-12');
        const card = document.createElement('div');
        card.classList.add('card');
        const image = document.createElement('img');
        image.classList.add('card-img-top');
        image.setAttribute('src', cardsItems[i].imagen);
        image.setAttribute('alt', cardsItems[i].titulo);
        const title = document.createElement('h4');
        title.classList.add('card-title', 'rounded-bottom','bg-warning','fw-bold','text-center','py-3');
        title.textContent = cardsItems[i].titulo;
        const cardInfo = document.createElement('div');
        cardInfo.classList.add('card-info');
        const description = document.createElement('h4');
        description.classList.add('card-text');
        description.textContent = cardsItems[i].descripción;
        const price = document.createElement('h3');
        price.classList.add('card-price');
        price.textContent = cardsItems[i].price;
        cardInfo.appendChild(description);
        cardInfo.appendChild(price);
        const cardBody = document.createElement('div');
        cardBody.classList.add('card-body', 'hidden');
        image.addEventListener('click', function() {
            cardBody.classList.toggle('hidden');
        });
        cardBody.appendChild(cardInfo);
        card.appendChild(title);
        card.appendChild(image);
        card.appendChild(cardBody);
        col.appendChild(card);
        cardsContainer.appendChild(col);
    }
})
.catch(error => {
    console.error('An error occurred', error);
});
